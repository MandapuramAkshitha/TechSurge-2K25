import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import MapPage from './pages/MapPage';
import TripPlannerPage from './pages/TripPlannerPage';
import InsightsPage from './pages/InsightsPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import VoiceAssistant from './components/VoiceAssistant';
import { ThemeProvider } from './contexts/ThemeContext';

function App() {
  const [voiceCommand, setVoiceCommand] = useState<string>('');

  const handleVoiceCommand = (command: string) => {
    console.log('Voice command received:', command);
    setVoiceCommand(command);
    
    // Pass command to current page if needed
    if (window.location.pathname === '/map') {
      // The MapPage will handle its own voice commands
      console.log('MapPage will handle voice command:', command);
    }
  };

  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/map" element={<MapPage />} />
              <Route path="/trip-planner" element={<TripPlannerPage />} />
              <Route path="/insights" element={<InsightsPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
            </Routes>
          </main>
          <Footer />
          <VoiceAssistant onCommand={handleVoiceCommand} />
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;