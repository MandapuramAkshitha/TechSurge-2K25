import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Navigation, 
  Clock, 
  DollarSign, 
  Zap,
  Leaf,
  ArrowRight,
  Route,
  Battery
} from 'lucide-react';

interface TripPlan {
  route: {
    distance: number;
    duration: number;
    cost: number;
  };
  chargingStops: Array<{
    name: string;
    location: string;
    chargingTime: number;
    cost: number;
    renewable: boolean;
  }>;
  recommendations: string[];
}

const TripPlannerPage = () => {
  const [formData, setFormData] = useState({
    from: '',
    to: '',
    vehicleModel: 'Model S',
    batteryCapacity: '100',
    currentCharge: '80',
    preferredCharging: 'cost',
    prioritizeRenewable: false
  });

  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);
  const [dynamicRoute, setDynamicRoute] = useState({
    distance: 0,
    duration: 0,
    cost: 0
  });

  // Calculate dynamic route summary based on form inputs
  const calculateDynamicRoute = (from: string, to: string, vehicleModel: string, batteryCapacity: string, currentCharge: string) => {
    if (!from || !to) {
      setDynamicRoute({ distance: 0, duration: 0, cost: 0 });
      return;
    }

    const fromLocation = from.toLowerCase();
    const toLocation = to.toLowerCase();
    
    // Calculate dynamic distance based on locations
    let distance = 0;
    let duration = 0;
    let cost = 0;
    
    // Distance calculation based on common routes
    if (fromLocation.includes('secunderabad') && toLocation.includes('medchal')) {
      distance = 25;
      duration = 0.8;
      cost = 65;
    } else if (fromLocation.includes('medchal') && toLocation.includes('secunderabad')) {
      distance = 25;
      duration = 0.8;
      cost = 65;
    } else if (fromLocation.includes('narsapur') && toLocation.includes('hyderabad')) {
      distance = 45;
      duration = 1.2;
      cost = 85;
    } else if (fromLocation.includes('hyderabad') && toLocation.includes('narsapur')) {
      distance = 45;
      duration = 1.2;
      cost = 85;
    } else if (fromLocation.includes('medak') && toLocation.includes('hyderabad')) {
      distance = 95;
      duration = 2.1;
      cost = 120;
    } else if (fromLocation.includes('hyderabad') && toLocation.includes('medak')) {
      distance = 95;
      duration = 2.1;
      cost = 120;
    } else if (fromLocation.includes('komapally') && toLocation.includes('hyderabad')) {
      distance = 18;
      duration = 0.6;
      cost = 45;
    } else if (fromLocation.includes('hyderabad') && toLocation.includes('komapally')) {
      distance = 18;
      duration = 0.6;
      cost = 45;
    } else if (fromLocation.includes('shamshabad') && toLocation.includes('hyderabad')) {
      distance = 35;
      duration = 1.0;
      cost = 75;
    } else if (fromLocation.includes('hyderabad') && toLocation.includes('shamshabad')) {
      distance = 35;
      duration = 1.0;
      cost = 75;
    } else {
      // Default calculation for unknown routes
      distance = Math.floor(Math.random() * 50) + 20; // 20-70 km
      duration = parseFloat((distance / 50).toFixed(1)); // Assuming 50 km/h average
      cost = Math.round(distance * 2.5); // ₹2.5 per km
    }
    
    // Adjust cost based on vehicle model and battery capacity
    const batteryCapacityNum = parseInt(batteryCapacity);
    const currentChargeNum = parseInt(currentCharge);
    
    if (vehicleModel === 'Model S') {
      cost = Math.round(cost * 1.2); // Tesla Model S is more expensive
    } else if (vehicleModel === 'Tata Nexon EV') {
      cost = Math.round(cost * 0.8); // Tata is more economical
    }
    
    // Adjust based on battery capacity
    if (batteryCapacityNum > 100) {
      cost = Math.round(cost * 1.1);
    } else if (batteryCapacityNum < 50) {
      cost = Math.round(cost * 0.9);
    }
    
    // Adjust based on current charge level
    if (currentChargeNum < 30) {
      cost = Math.round(cost * 1.3); // Need more charging
    } else if (currentChargeNum > 80) {
      cost = Math.round(cost * 0.8); // Less charging needed
    }
    
    setDynamicRoute({
      distance: Math.round(distance),
      duration: duration,
      cost: cost
    });
  };

  // Update dynamic route when form data changes
  useEffect(() => {
    calculateDynamicRoute(
      formData.from,
      formData.to,
      formData.vehicleModel,
      formData.batteryCapacity,
      formData.currentCharge
    );
  }, [formData.from, formData.to, formData.vehicleModel, formData.batteryCapacity, formData.currentCharge]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsPlanning(true);

    // Simulate API call with dynamic data based on user inputs
    setTimeout(() => {
      // Generate dynamic data based on form inputs
      const fromLocation = formData.from.toLowerCase();
      const toLocation = formData.to.toLowerCase();
      
      // Calculate dynamic distance based on locations (simplified logic)
      let distance = 287; // default
      let duration = 4.5; // default
      let cost = 145; // default
      
      // Adjust based on locations
      if (fromLocation.includes('narsapur') && toLocation.includes('hyderabad')) {
        distance = 45;
        duration = 1.2;
        cost = 85;
      } else if (fromLocation.includes('medak') && toLocation.includes('hyderabad')) {
        distance = 95;
        duration = 2.1;
        cost = 120;
      } else if (fromLocation.includes('secunderabad') && toLocation.includes('hyderabad')) {
        distance = 12;
        duration = 0.4;
        cost = 35;
      } else if (fromLocation.includes('komapally') && toLocation.includes('hyderabad')) {
        distance = 18;
        duration = 0.6;
        cost = 45;
      } else if (fromLocation.includes('shamshabad') && toLocation.includes('hyderabad')) {
        distance = 35;
        duration = 1.0;
        cost = 75;
      }
      
      // Adjust cost based on vehicle model and battery capacity
      const batteryCapacity = parseInt(formData.batteryCapacity);
      const currentCharge = parseInt(formData.currentCharge);
      
      if (formData.vehicleModel === 'Model S') {
        cost = Math.round(cost * 1.2); // Tesla Model S is more expensive
      } else if (formData.vehicleModel === 'Tata Nexon EV') {
        cost = Math.round(cost * 0.8); // Tata is more economical
      }
      
      // Adjust based on battery capacity
      if (batteryCapacity > 100) {
        cost = Math.round(cost * 1.1);
      } else if (batteryCapacity < 50) {
        cost = Math.round(cost * 0.9);
      }
      
      // Adjust based on current charge level
      if (currentCharge < 30) {
        cost = Math.round(cost * 1.3); // Need more charging
      } else if (currentCharge > 80) {
        cost = Math.round(cost * 0.8); // Less charging needed
      }
      
      // Generate dynamic charging stops based on route
      let chargingStops = [];
      
      if (distance > 100) {
        chargingStops = [
          {
            name: 'Highway Solar Hub',
            location: `${fromLocation.charAt(0).toUpperCase() + fromLocation.slice(1)} - ${toLocation.charAt(0).toUpperCase() + toLocation.slice(1)} Highway`,
            chargingTime: Math.round(25 + Math.random() * 15),
            cost: Math.round(280 + Math.random() * 100),
            renewable: formData.prioritizeRenewable
          },
          {
            name: 'Green Energy Station',
            location: `${toLocation.charAt(0).toUpperCase() + toLocation.slice(1)} City Center`,
            chargingTime: Math.round(20 + Math.random() * 20),
            cost: Math.round(200 + Math.random() * 80),
            renewable: formData.prioritizeRenewable
          }
        ];
      } else if (distance > 50) {
        chargingStops = [
          {
            name: 'Midway Charging Point',
            location: `Between ${fromLocation.charAt(0).toUpperCase() + fromLocation.slice(1)} and ${toLocation.charAt(0).toUpperCase() + toLocation.slice(1)}`,
            chargingTime: Math.round(15 + Math.random() * 10),
            cost: Math.round(150 + Math.random() * 50),
            renewable: formData.prioritizeRenewable
          }
        ];
      } else {
        chargingStops = [
          {
            name: 'Destination Charging Hub',
            location: `${toLocation.charAt(0).toUpperCase() + toLocation.slice(1)}`,
            chargingTime: Math.round(10 + Math.random() * 15),
            cost: Math.round(80 + Math.random() * 40),
            renewable: formData.prioritizeRenewable
          }
        ];
      }
      
      // Generate dynamic recommendations based on inputs
      const recommendations = [
        `Start your journey with ${currentCharge}% battery to minimize charging stops`,
        `${formData.prioritizeRenewable ? 'Solar charging stations will save you ₹' + Math.round(cost * 0.15) + ' compared to grid power' : 'Consider renewable energy stations for better sustainability'}`,
        `Optimal charging time is between 2 PM - 4 PM for best rates`,
        `Your ${formData.vehicleModel} with ${batteryCapacity}kWh battery is ${batteryCapacity > 80 ? 'well-suited' : 'may need frequent charging'} for this ${distance}km journey`
      ];
      
      if (formData.preferredCharging === 'time') {
        recommendations.push('Fast charging stations prioritized for minimal travel time');
      } else if (formData.preferredCharging === 'cost') {
        recommendations.push('Cost-optimized route selected to minimize expenses');
      } else {
        recommendations.push('Balanced approach considers both time and cost efficiency');
      }

      const mockPlan: TripPlan = {
        route: {
          distance,
          duration,
          cost
        },
        chargingStops,
        recommendations
      };
      
      setTripPlan(mockPlan);
      setIsPlanning(false);
    }, 2000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8 transition-colors duration-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Smart Trip Planner
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Plan your EV journey with intelligent route optimization and charging recommendations
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Trip Planning Form */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors duration-200">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Trip Details</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      From
                    </label>
                    <input
                      type="text"
                      name="from"
                      value={formData.from}
                      onChange={handleInputChange}
                      placeholder="Enter starting location"
                      className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      To
                    </label>
                    <input
                      type="text"
                      name="to"
                      value={formData.to}
                      onChange={handleInputChange}
                      placeholder="Enter destination"
                      className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Vehicle Model
                    </label>
                    <select
                      name="vehicleModel"
                      value={formData.vehicleModel}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                    >
                      <option value="">Select Vehicle</option>
                      <option value="Tesla Model 3">Tesla Model 3</option>
                      <option value="Nexon EV">Nexon EV</option>
                      <option value="Tata Tigor EV">Tata Tigor EV</option>
                      <option value="MG ZS EV">MG ZS EV</option>
                      <option value="Hyundai Kona">Hyundai Kona</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Battery Capacity (kWh)
                    </label>
                    <input
                      type="number"
                      name="batteryCapacity"
                      value={formData.batteryCapacity}
                      onChange={handleInputChange}
                      placeholder="e.g., 50"
                      className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Current Charge (%)
                    </label>
                    <input
                      type="number"
                      name="currentCharge"
                      value={formData.currentCharge}
                      onChange={handleInputChange}
                      placeholder="e.g., 80"
                      min="0"
                      max="100"
                      className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isPlanning}
                  className="w-full bg-green-600 text-white py-3 px-6 rounded-md font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isPlanning ? 'Planning Route...' : 'Plan My Trip'}
                </button>
              </form>
            </div>
          </div>

          {/* Trip Plan Results */}
          <div className="space-y-6">
            {/* Dynamic Route Summary - Always visible when source/destination is entered */}
            {(formData.from || formData.to) && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors duration-200">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                  <Navigation className="h-5 w-5 mr-2 text-green-500" />
                  Route Summary
                </h2>

                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {dynamicRoute.distance > 0 ? dynamicRoute.distance : '--'}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">km</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                      {dynamicRoute.duration > 0 ? dynamicRoute.duration : '--'}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">hours</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                      {dynamicRoute.cost > 0 ? `₹${dynamicRoute.cost}` : '--'}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">total cost</div>
                  </div>
                </div>

                {!formData.from || !formData.to ? (
                  <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
                    <p className="text-sm text-yellow-800 dark:text-yellow-200">
                      Enter both source and destination to see route details
                    </p>
                  </div>
                ) : null}
              </div>
            )}

            {tripPlan ? (
              <>
                {/* Charging Stops */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors duration-200">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Charging Stops</h3>
                  <div className="space-y-4">
                    {tripPlan.chargingStops.map((stop, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 dark:text-white">{stop.name}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{stop.location}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-500">
                            Charge: {stop.chargingTime} min | Cost: ₹{stop.cost}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* AI Recommendations */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors duration-200">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">AI Recommendations</h3>
                  <div className="space-y-3">
                    {tripPlan.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">{rec}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-8 text-center transition-colors duration-200">
                <div className="text-gray-400 dark:text-gray-500 mb-4">
                  <Navigation className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Plan Your Trip</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Enter your trip details to get personalized route recommendations with optimal charging stops.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TripPlannerPage;