import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Filter, 
  Zap, 
  DollarSign, 
  Clock,
  Leaf,
  Navigation,
  RefreshCw
} from 'lucide-react';
import EVMap from '../components/EVMap';

interface ChargingStation {
  id: string;
  name: string;
  location: { lat: number; lng: number };
  address: string;
  type: 'fast' | 'standard' | 'rapid';
  availability: 'available' | 'busy' | 'full';
  price: number;
  renewable: boolean;
  distance: number;
  connectorTypes: string[];
}

const MapPage = () => {
  const [stations, setStations] = useState<ChargingStation[]>([]);
  const [selectedStation, setSelectedStation] = useState<ChargingStation | null>(null);
  const [filter, setFilter] = useState({
    availability: 'all',
    type: 'all',
    renewable: false,
    maxPrice: 100
  });
  const [showMap, setShowMap] = useState(true);

  // Handle voice commands
  const handleVoiceCommand = (command: string) => {
    console.log('Voice command received in MapPage:', command);
    
    if (command === 'search_stations') {
      // Trigger station search - could be enhanced with geolocation
      console.log('Searching for nearby stations');
    } else if (command.startsWith('search_stations_location:')) {
      const location = command.split(':')[1];
      console.log(`Searching for stations near ${location}`);
      // Could integrate with geocoding API here
    } else if (command === 'filter_available') {
      setFilter(prev => ({ ...prev, availability: 'available' }));
    } else if (command === 'filter_fast') {
      setFilter(prev => ({ ...prev, type: 'fast' }));
    } else if (command === 'filter_renewable') {
      setFilter(prev => ({ ...prev, renewable: true }));
    } else if (command === 'filter_cheap') {
      setFilter(prev => ({ ...prev, maxPrice: 10 }));
    } else if (command === 'clear_filters') {
      setFilter({
        availability: 'all',
        type: 'all',
        renewable: false,
        maxPrice: 100
      });
    } else if (command === 'count_stations') {
      const count = filteredStations.length;
      console.log(`Found ${count} charging stations`);
      // Could trigger a speech response here
    }
  };

  // Mock charging stations data
  useEffect(() => {
    const mockStations: ChargingStation[] = [
      {
        id: '1',
        name: 'BVRIT Food Court EV',
        location: { lat: 17.7250, lng: 78.2565 },
        address: 'BVRIT Food Court, Narsapur',
        type: 'fast',
        availability: 'full',
        price: 14,
        renewable: false,
        distance: 0.3,
        connectorTypes: ['Type 2', 'CCS']
      },
      {
        id: '2',
        name: 'Tuljarampet Road Charging',
        location: { lat: 17.7235, lng: 78.2580 },
        address: 'Tuljarampet Road, Narsapur',
        type: 'standard',
        availability: 'available',
        price: 11,
        renewable: true,
        distance: 1.0,
        connectorTypes: ['Type 2']
      },
      {
        id: '3',
        name: 'Narsapur Solar Hub',
        location: { lat: 17.9140, lng: 78.0000 },
        address: 'Narsapur, Telangana',
        type: 'fast',
        availability: 'available',
        price: 12,
        renewable: true,
        distance: 2.3,
        connectorTypes: ['CCS', 'Type 2']
      },
      {
        id: '4',
        name: 'BVRIT Main Gate Charging',
        location: { lat: 17.7262, lng: 78.2557 },
        address: 'BVRIT Main Gate, Narsapur',
        type: 'fast',
        availability: 'available',
        price: 13,
        renewable: true,
        distance: 0.2,
        connectorTypes: ['CCS', 'Type 2']
      },
      {
        id: '5',
        name: 'SR Convention EV Point',
        location: { lat: 17.7280, lng: 78.2530 },
        address: 'SR Convention, Narsapur',
        type: 'standard',
        availability: 'busy',
        price: 12,
        renewable: false,
        distance: 0.5,
        connectorTypes: ['Type 2']
      },
      {
        id: '6',
        name: 'VIPER Hostel Charging',
        location: { lat: 17.7295, lng: 78.2570 },
        address: 'VIPER Hostel, Narsapur',
        type: 'rapid',
        availability: 'available',
        price: 15,
        renewable: true,
        distance: 0.7,
        connectorTypes: ['CCS']
      },
      {
        id: '7',
        name: 'Medak Central Station',
        location: { lat: 18.0456, lng: 78.2600 },
        address: 'Medak, Telangana',
        type: 'rapid',
        availability: 'busy',
        price: 18,
        renewable: false,
        distance: 5.1,
        connectorTypes: ['CHAdeMO', 'CCS']
      },
      {
        id: '8',
        name: 'SitaramPur Green Energy',
        location: { lat: 17.9000, lng: 78.1000 },
        address: 'SitaramPur, Telangana',
        type: 'standard',
        availability: 'available',
        price: 8,
        renewable: true,
        distance: 3.7,
        connectorTypes: ['Type 2', 'Bharat AC']
      },
      {
        id: '9',
        name: 'Moosapet Express Charging',
        location: { lat: 17.4500, lng: 78.4500 },
        address: 'Moosapet, Hyderabad',
        type: 'rapid',
        availability: 'full',
        price: 22,
        renewable: false,
        distance: 8.2,
        connectorTypes: ['CCS', 'CHAdeMO']
      },
      {
        id: '10',
        name: 'Chandapur Eco Station',
        location: { lat: 17.8000, lng: 78.2000 },
        address: 'Chandapur, Telangana',
        type: 'fast',
        availability: 'available',
        price: 15,
        renewable: true,
        distance: 1.8,
        connectorTypes: ['Type 2', 'CCS']
      },
      {
        id: '11',
        name: 'Cyber City Charging Hub',
        location: { lat: 17.4401, lng: 78.3489 },
        address: 'HiTech City, Hyderabad',
        type: 'rapid',
        availability: 'available',
        price: 16,
        renewable: true,
        distance: 0.8,
        connectorTypes: ['CCS', 'CHAdeMO', 'Type 2']
      },
      // New stations
      {
        id: '12',
        name: 'Komapally EV Point',
        location: { lat: 17.5700, lng: 78.4800 },
        address: 'Komapally, Hyderabad',
        type: 'fast',
        availability: 'available',
        price: 13,
        renewable: true,
        distance: 6.5,
        connectorTypes: ['CCS', 'Type 2']
      },
      {
        id: '13',
        name: 'Suchitra Charging Hub',
        location: { lat: 17.5000, lng: 78.4800 },
        address: 'Suchitra, Hyderabad',
        type: 'rapid',
        availability: 'busy',
        price: 17,
        renewable: false,
        distance: 7.2,
        connectorTypes: ['CHAdeMO', 'CCS']
      },
      {
        id: '14',
        name: 'Bowenpally Charge Zone',
        location: { lat: 17.4600, lng: 78.4800 },
        address: 'Bowenpally, Hyderabad',
        type: 'standard',
        availability: 'available',
        price: 11,
        renewable: true,
        distance: 5.8,
        connectorTypes: ['Type 2', 'Bharat AC']
      },
      {
        id: '15',
        name: 'Shamshabad Supercharge',
        location: { lat: 17.2500, lng: 78.4300 },
        address: 'Shamshabad, Hyderabad',
        type: 'rapid',
        availability: 'full',
        price: 20,
        renewable: false,
        distance: 18.0,
        connectorTypes: ['CCS', 'CHAdeMO']
      },
      {
        id: '16',
        name: 'Tank Bund EV Station',
        location: { lat: 17.4239, lng: 78.4746 },
        address: 'Tank Bund, Hyderabad',
        type: 'fast',
        availability: 'available',
        price: 14,
        renewable: true,
        distance: 2.0,
        connectorTypes: ['Type 2', 'CCS']
      },
      // New EV Stations
      {
        id: '17',
        name: 'Gummadidala EV Station',
        location: { lat: 17.6500, lng: 78.3500 },
        address: 'Gummadidala, Hyderabad',
        type: 'standard',
        availability: 'available',
        price: 13,
        renewable: true,
        distance: 3.2,
        connectorTypes: ['Type 2']
      },
      {
        id: '18',
        name: 'Gandimaisamma Charging Hub',
        location: { lat: 17.6800, lng: 78.3800 },
        address: 'Gandimaisamma, Hyderabad',
        type: 'fast',
        availability: 'available',
        price: 12,
        renewable: true,
        distance: 2.8,
        connectorTypes: ['Type 2', 'CCS']
      },
      {
        id: '19',
        name: 'Maisammaguda Solar Station',
        location: { lat: 17.7200, lng: 78.4200 },
        address: 'Maisammaguda, Hyderabad',
        type: 'rapid',
        availability: 'available',
        price: 11,
        renewable: true,
        distance: 1.5,
        connectorTypes: ['CCS', 'CHAdeMO']
      },
      {
        id: '20',
        name: 'Muneerabad EV Point',
        location: { lat: 17.7500, lng: 78.4500 },
        address: 'Muneerabad, Hyderabad',
        type: 'standard',
        availability: 'busy',
        price: 14,
        renewable: false,
        distance: 2.1,
        connectorTypes: ['Type 2']
      },
      {
        id: '21',
        name: 'Gagillaput Charging Zone',
        location: { lat: 17.7800, lng: 78.4800 },
        address: 'Gagillaput, Hyderabad',
        type: 'fast',
        availability: 'available',
        price: 13,
        renewable: true,
        distance: 3.5,
        connectorTypes: ['Type 2', 'CCS']
      },
      {
        id: '22',
        name: 'Bolarum EV Station',
        location: { lat: 17.8100, lng: 78.5100 },
        address: 'Bolarum, Hyderabad',
        type: 'rapid',
        availability: 'available',
        price: 15,
        renewable: true,
        distance: 4.2,
        connectorTypes: ['CCS', 'CHAdeMO']
      },
      {
        id: '23',
        name: 'Ayodhya X Roads Charging',
        location: { lat: 17.8400, lng: 78.5400 },
        address: 'Ayodhya X Roads, Hyderabad',
        type: 'standard',
        availability: 'available',
        price: 12,
        renewable: false,
        distance: 2.8,
        connectorTypes: ['Type 2']
      },
      {
        id: '24',
        name: 'Medchal Check Post EV',
        location: { lat: 17.8700, lng: 78.5700 },
        address: 'Medchal Check Post, Hyderabad',
        type: 'fast',
        availability: 'available',
        price: 16,
        renewable: true,
        distance: 1.8,
        connectorTypes: ['Type 2', 'CCS']
      },
      {
        id: '25',
        name: 'Shamirpet Charging Hub',
        location: { lat: 17.9000, lng: 78.6000 },
        address: 'Shamirpet, Hyderabad',
        type: 'rapid',
        availability: 'full',
        price: 14,
        renewable: true,
        distance: 5.1,
        connectorTypes: ['CCS', 'CHAdeMO']
      }
      
    ];
    setStations(mockStations);
  }, []);

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'available': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'full': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getAvailabilityText = (availability: string) => {
    switch (availability) {
      case 'available': return 'Available';
      case 'busy': return 'Busy';
      case 'full': return 'Full';
      default: return 'Unknown';
    }
  };

  const filteredStations = stations.filter(station => {
    if (filter.availability !== 'all' && station.availability !== filter.availability) return false;
    if (filter.type !== 'all' && station.type !== filter.type) return false;
    if (filter.renewable && !station.renewable) return false;
    if (station.price > filter.maxPrice) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-4 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">EV Route Planner</h1>
          <p className="text-gray-600 dark:text-gray-400">Plan your journey with Source and Destination using Mapbox</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700 transition-colors duration-200">
              <div className="flex items-center mb-4">
                <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Filters</h2>
              </div>

              <div className="space-y-4">
                {/* Availability Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Availability
                  </label>
                  <select
                    value={filter.availability}
                    onChange={(e) => setFilter({ ...filter, availability: e.target.value })}
                    className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                  >
                    <option value="all">All Stations</option>
                    <option value="available">Available</option>
                    <option value="busy">Busy</option>
                    <option value="full">Full</option>
                  </select>
                </div>

                {/* Type Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Charging Type
                  </label>
                  <select
                    value={filter.type}
                    onChange={(e) => setFilter({ ...filter, type: e.target.value })}
                    className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500 dark:bg-gray-700 dark:text-white transition-colors duration-200"
                  >
                    <option value="all">All Types</option>
                    <option value="standard">Standard</option>
                    <option value="fast">Fast</option>
                    <option value="rapid">Rapid</option>
                  </select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Max Price (₹/kWh): {filter.maxPrice}
                  </label>
                  <input
                    type="range"
                    min="5"
                    max="30"
                    value={filter.maxPrice}
                    onChange={(e) => setFilter({ ...filter, maxPrice: parseInt(e.target.value) })}
                    className="w-full accent-green-500"
                  />
                </div>

                {/* Renewable Energy */}
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="renewable"
                    checked={filter.renewable}
                    onChange={(e) => setFilter({ ...filter, renewable: e.target.checked })}
                    className="text-green-500 focus:ring-green-500 dark:bg-gray-700 dark:border-gray-600"
                  />
                  <label htmlFor="renewable" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Renewable Energy Only
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Map and Station List */}
          <div className="lg:col-span-3 space-y-6">
            {/* Mapbox Map */}
            {showMap && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden transition-colors duration-200">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Interactive Map</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Click on the map to set source and destination points</p>
                </div>
                <EVMap />
              </div>
            )}

            {/* Station List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Nearby Stations ({filteredStations.length})
                </h2>
                <button className="flex items-center text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300 transition-colors duration-200">
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredStations.map((station) => (
                  <div
                    key={station.id}
                    className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
                    onClick={() => setSelectedStation(station)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{station.name}</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">{station.address}</p>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${getAvailabilityColor(station.availability)}`}></div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                        <DollarSign className="h-4 w-4 mr-1" />
                        ₹{station.price}/kWh
                      </div>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                        <Navigation className="h-4 w-4 mr-1" />
                        {station.distance} km
                      </div>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                        <Zap className="h-4 w-4 mr-1" />
                        {station.type.charAt(0).toUpperCase() + station.type.slice(1)}
                      </div>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                        {station.renewable ? (
                          <>
                            <Leaf className="h-4 w-4 mr-1 text-green-500" />
                            Renewable
                          </>
                        ) : (
                          <>
                            <Zap className="h-4 w-4 mr-1" />
                            Grid Power
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        station.availability === 'available' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' :
                        station.availability === 'busy' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400' :
                        'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                      }`}>
                        {getAvailabilityText(station.availability)}
                      </span>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {station.connectorTypes.join(', ')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapPage;